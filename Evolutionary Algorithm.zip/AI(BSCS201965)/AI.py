import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt
populations = 100

# reading image using opencv
img_rgb = cv.imread("groupGray.jpg", cv.IMREAD_GRAYSCALE)


img_gray = cv.cvtColor(img_rgb,cv.IMREAD_GRAYSCALE)
templete = cv.imread("boothiGray.jpg",0)

# print("***",img_rgb,"****",templete)
col = np.random.randint(1024,size = (populations))
row = np.random.randint(512,size = (populations))
# print(col,row)
def fitnessValue(self,x,y):
    if x > -11 and x < 11:
        y = (x**2+x)*np.cos(2*x) + x**2
        return round(y,6)
    else:
        return 0
fitness = np. vectorize(fitnessValue)
#for the mutation function
def mutation(parents,fitnessValue):
    n = int(len(parents))
    scores = fitnessValue(parents)
    index = scores > 0
    scores = scores[index]
    parents = np.array(parents)[index]
    children = np.random.choice(parents,size=n,p=scores / scores.sum())
    children = children+np.random.uniform(-0.51,0.51 , size = n)
    return children.tolist()
def GA(parents,fitnessValue,popsize = 100,max_iter = 100):
    History = []
    best_fitness = fitnessValue(parents,fitness)
    print("generation {}| best fitness {}|current fitness{}|current parent{}".format(0,best_fitness))
    x = np.linspace(start=20,stop = 20,num = 200)
    plt.plot(x,fitnessValue(x))
    plt.scatter(parents,fitnessValue(parents),marker="x")
    for i in range(1,max_iter):
        parents = mutation(parents,fitnessValue = fitnessValue)
        curr_parent = curr_fitness = fitnessValue(parents,fitnessValue)
        if curr_fitness > best_fitness:
            best_fitness = curr_fitness
            best_parent = curr_parent
            curr_parent,curr_fitness = fitnessValue(parents,fitnessValue)
            if i % 10 == 0:
                print("generation {}| best fitness {}|current fitness{}|current parent{}".format(0,best_fitness))
                History.append((i,np.max(fitnessValue(parents))))
            cv.calcHist(parents,fitnessValue(parents))
            plt.scatter(best_parent,fitnessValue(best_parent),marker=".",c="b", s = 200)
            plt.pause(0.09)
            plt.ioff()
            print("generation {}| best fitness {}|best parent{}".format(0,best_fitness,best_parent))
            return best_parent,best_fitness,History
def get_fittest_parent(parents,fitness):
    _fitness = fitness(parents)
    PFitness = list(zip(parents,_fitness))
    PFitness.sort(key = lambda x: x[i],reverse=True)
    best_parent,best_fitness = PFitness[0]
    return round(best_parent,4), round(best_fitness,4)
x = np.linspace(start=-20,stop=20,num = 200)
init_pop = np.random.uniform(low = -20,high = 20,size = 100)
parent_,fitness_,History_ = GA(init_pop,fitness)
print("top parent (),top fitness{}".format(parent_,fitness_)
x = list(zip(History_)
plt.plot(x,y)
plt.title("Maximum fitness")
plt.xlabel("Generation")
plt.ylabel("Fitness")





# def population(self,row,col,sizeofpop,num_weight):
#     self.row = row
#     self.col = col
#     self.sizeofpop = sizeofpop


# pop_size = 100 

# # #Creating the initial population.
# new_population = numpy.random.uniform(low=-1.0, high=1.0, size=pop_size)
# print(new_population)
# # population()